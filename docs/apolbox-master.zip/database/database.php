<?php

namespace Database;

class Database {
	
}