<?php
/*
 * Apolbox - System
 * (c) Ayus irfang filaras <ayus.sahabat@gmail.com>
 */
namespace PHP\Utilities;
/**
 * 
 * @author ASUS-K40IJ
 *
 */
abstract class System extends Konfigurasi
{
	public function onStart()
	{
		return $this->systemCenter();
	}

	public function onStop()
	{

	}
}


