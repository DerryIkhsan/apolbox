<?php
/*
 * Apolbox - PHP Map
 * (c) Ayus irfang filaras <ayus.sahabat@gmail.com>
 */
namespace PHP\Utilities;
/**
 *
 */
trait PHPMap
{
	/**
	 *
	 */
	public function php_directory()
	{
		$phpmap = parse_ini_file('phpmap.ini');
	}
}