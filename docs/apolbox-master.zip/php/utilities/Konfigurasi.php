<?php
/*
 * Apolbox - System Konfigurasi
 * (c) Ayus irfang filaras <ayus.sahabat@gmail.com>
 */
namespace PHP\Utilities;
/**
 * 
 */
abstract class Konfigurasi
{
	use PHPMap;

	/**
	 *
	 */
	public function systemCenter()
	{
		return PHPMap->php_directory();
	}
}
