<?php

namespace Pustaka\Test;

class TestClassLocal
{
	public function __construct()
	{
		echo "Hello world";
	}
}

?>