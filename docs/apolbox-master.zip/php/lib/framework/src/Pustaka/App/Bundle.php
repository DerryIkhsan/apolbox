<?php
/*
 * Apolbox - Pustaka Bundle
 *
 * (c) Ayus irfang filaras <ayus.sahabat@gmail.com>
 */
namespace Pustaka\App;

/**
 * 
 */
class Bundle extends \PHPCenter\App\Bundle
{
    // TODO: Tidak ada metode yang dideklarasikan
}