<?php
/*
 * Apolbox - Pustaka library
 * 
 * (c) Ayus Irfang Filaras <ayus.sahabat@gmail.com>
 */
namespace Pustaka\App;

use PHPCenter\App\Bootstrap;

final class Aplikasi extends Bootstrap
{
    /**
     * Metode yang dipanggil secara otomatis saat
     * kelas dideklarasikan atau dimuat.
     * 
     * @return null
     */
    final public function __construct() {}
    
    /**
     * 
     */
    final public static function checkInstalled()
    {
        parent::checkInstalled();
    }
   
    final public static function installed()
    {
        parent::installed();
    }
}

