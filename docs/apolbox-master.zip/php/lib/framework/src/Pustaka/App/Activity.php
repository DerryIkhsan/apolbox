<?php
/*
 * Apolbox - Pustaka Activity
 *
 * (c) Ayus irfang filaras <ayus.sahabat@gmail.com>
 */
namespace Pustaka\App;

/**
 * 
 */
class Activity extends \PHPCenter\App\Activity
{
    // TODO: Tidak ada metode yang dideklarasikan.
}